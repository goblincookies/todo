let listContainers;
let draggableItem;
let pointerStart = {x:0, y:0};
let listOriginIndex = [];
let dragIndex = -1;
let dragIndexOrigin = -1
let liHeight = 56; //40+16

function setup() {

    listContainers = document.querySelectorAll(".list");
    if (!listContainers) return;
    
    listContainers.forEach( list => {
        list.addEventListener("mousedown", dragStart);
    });

    document.addEventListener("mouseup", dragEnd );

};

function initDraggable() {
    draggableItem.classList.remove("isIdle");
    draggableItem.classList.add("isDragging");
};

function initListOrigins() {
    listOriginIndex = draggableItem.parentNode.querySelectorAll("li");
    dragIndex = Array.from(listOriginIndex).indexOf( draggableItem );
    dragIndexOrigin = dragIndex;
    console.log(dragIndex, listOriginIndex);
};

function unsetDraggable() {
    draggableItem.style = null;
    draggableItem.classList.remove("isDragging");
    draggableItem.classList.add("isIdle");
    draggableItem = null;
};

function updateIdlePositions( delta ){
    let newIndex = Math.floor( Math.abs(delta.y) / liHeight);
    
    if( dragIndex != (dragIndexOrigin - newIndex)) {
        // MOVED!
        
        console.log( `deltaY: ${delta.y} li Height: ${liHeight} new Index: ${newIndex}`)
        console.log(`direction: ${ Math.sign( dragIndex - (dragIndexOrigin - newIndex) ) }`);
        console.log(`moved! ${dragIndex}`)

        dragIndex = dragIndexOrigin - newIndex;
    }
};
function dragStart(e) {
    console.log("Drag Start!!");
    if (e.target.classList.contains("js-drag-handle")) {
        draggableItem = e.target.closest(".item");
    };

    if(!draggableItem) return;

    pointerStart.x = e.clientX;
    pointerStart.y = e.clientY;

    initDraggable();
    initListOrigins();

    document.addEventListener("mousemove", drag);
};

function drag(e) {
    console.log("DRAGGING!!");
    if (!draggableItem) return;

    const currentPos = {
        x: e.clientX,
        y: e.clientY,
    };

    const pointerOffset = {
        x: currentPos.x - pointerStart.x,
        y: currentPos.y - pointerStart.y,
    };

    updateIdlePositions( pointerOffset );
    draggableItem.style.transform = `translate( ${pointerOffset.x}px, ${pointerOffset.y}px)`;
};

function dragEnd() {
    console.log("Drag END");
    if (!draggableItem) return;
    cleanup();    
};

function cleanup() {
    unsetDraggable();
    document.removeEventListener("mousemove", drag);
}

setup();